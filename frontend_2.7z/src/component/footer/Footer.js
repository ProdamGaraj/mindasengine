import "../footer/footer.scss";

export const Footer = () => {
    return(
        <footer className="footer container"> 
            <p>© MindAsEngine, 2023</p>
        </footer>
    )
}