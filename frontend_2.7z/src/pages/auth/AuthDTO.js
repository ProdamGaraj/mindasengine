export class UserDTO{
    
}